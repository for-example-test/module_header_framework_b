//
//  module_header_framework_test.h
//  module_header_framework_b
//
//  Created by tripleCC on 2/23/19.
//

#import <Foundation/Foundation.h>
#import <module_header_source_a/module_header_source_a.h>

NS_ASSUME_NONNULL_BEGIN

@interface module_header_framework_test : NSObject

@end

NS_ASSUME_NONNULL_END
